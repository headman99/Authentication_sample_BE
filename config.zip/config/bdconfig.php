<?php
/**
 * Created by PhpStorm.
 * User: dmormile
 * Date: 18/07/2019
 * Time: 14:47
 */
return [
    'url_base' => env('APP_REDIRECT')
    ];
