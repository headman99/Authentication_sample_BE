<div>
    You don't have privileges to access this route
</div>